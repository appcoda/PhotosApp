//
//  ViewController.swift
//  PhotosApp
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import Cocoa
import Quartz

class ViewController: NSViewController, QLPreviewPanelDataSource {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var collectionView: NSCollectionView!
    
    @IBOutlet weak var progressBar: NSProgressIndicator!
    
    @IBOutlet weak var filenameLabel: NSTextField!
    
    @IBOutlet weak var bottomView: NSView!
    
    
    // MARK: - Properties
    
    var photos = [[PhotoInfo]]()
    
    let thumbnailSize = NSSize(width: 130.0, height: 130.0)
    
    var showSectionHeaders = false
    
    var previewURL: URL?
    
    
    
    // MARK: - VC Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        configureUI()
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    
    // MARK: - Implemented Methods
    
    func configureUI() {
        self.progressBar.isHidden = true
        filenameLabel.stringValue = ""
    }
    
    
    func prepareToCreateThumbnails(for totalPhotos: Int) {
        progressBar.isHidden = false
        progressBar.minValue = 0.0
        progressBar.maxValue = Double(totalPhotos)
        progressBar.doubleValue = 0.0
        bottomView.isHidden = true
    }
    
    
    func performPostThumbnailCreationActions() {
        progressBar.isHidden = true
        bottomView.isHidden = false
    }
    
    
    func updateProgress(withValue value: Int) {
        progressBar.doubleValue = Double(value)
    }
    
    
    func getProcessedPhotos() {
        if photos.count > 0 {
            self.photos[self.photos.count - 1] = PhotoHelper.shared.photosToProcess
        }
    }
    
    
    func configureAndShowQuickLook() {
        guard let ql = QLPreviewPanel.shared() else { return }
        ql.dataSource = self
        ql.makeKeyAndOrderFront(self.view.window)
    }
    
    
    
    // MARK: - QLPreviewPanelDataSource
       
    func numberOfPreviewItems(in panel: QLPreviewPanel!) -> Int {
        return 1
    }

    
    func previewPanel(_ panel: QLPreviewPanel!, previewItemAt index: Int) -> QLPreviewItem! {
        guard let previewURL = previewURL else { return nil }
        return previewURL as QLPreviewItem
    }
    
    
    
    // MARK: - IBOutlet Properties
    
    @IBAction func importPhotos(_ sender: Any) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        
        panel.message = "Select a folder to import photos from..."
        let response = panel.runModal()
        
        if response == NSApplication.ModalResponse.OK {
            if let selectedURL = panel.directoryURL {
                var newPhotos = [PhotoInfo]()
                PhotoHelper.shared.importPhotoURLs(from: selectedURL, to: &newPhotos)
                photos.append(newPhotos)
                
                createThumbnails()
            }
        }
    }
    
    
    @IBAction func toggleSectionHeaders(_ sender: Any) {
        
    }
    
    
    @IBAction func removeSelectedPhotos(_ sender: Any) {
        
    }
    
    
    
    // MARK: - Put Methods To Implement Here
    
    func createThumbnails() {
        
    }
    

}

